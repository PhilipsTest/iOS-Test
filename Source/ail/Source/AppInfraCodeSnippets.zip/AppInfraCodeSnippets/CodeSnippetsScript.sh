#!/bin/bash

# Copyright (c) Koninklijke Philips N.V., 2016
# All rights are reserved. Reproduction or dissemination
# in whole or in part is prohibited without the prior written
# consent of the copyright holder.

red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`
blue=`tput setaf 4`

xcodeDirectory=${HOME}/Library/Developer/Xcode

if [ -d "${xcodeDirectory}" ] 
then

srcdir=$(dirname $0)

dstdir="${HOME}/Library/Developer/Xcode/UserData/CodeSnippets"

# create code snippets folder if not exists
mkdir -p ${dstdir}

for f in ${srcdir}/*.codesnippet
do
    cp $f $dstdir $dstfile
done
echo "${green} Code snippets are installed successfully ${reset}"

echo "${blue}Restart Xcode in order to use the new CodeSnippets ${reset}"
    
else
    echo "${red}Error: Xcode Directory not found at path ${xcodeDirectory}. Please verify and try again${reset}"
    exit
fi


