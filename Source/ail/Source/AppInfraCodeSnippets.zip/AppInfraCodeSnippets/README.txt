What are code snippets in Xcode?

Every iOS developer has used code snippets without necessarily identifying what they are. Have you ever started typing some code, the code completion prompt comes up with suggestions those are code snippets.

How to install the provided custom code snippets

Step1: Navigate to this folder in command prompt
Step2: Run the the script 'CodeSnippetsScript.sh' with the following command

$ sudo bash CodeSnippetsScript.sh

Step3: Restart your xcode to get the custom code snippets